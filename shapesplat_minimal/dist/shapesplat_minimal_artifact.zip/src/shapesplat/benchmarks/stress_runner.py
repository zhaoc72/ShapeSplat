from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch

from shapesplat.baselines.load_outputs import load_baseline_output
from shapesplat.benchmarks.stress_metadata import load_stress_metadata
from shapesplat.benchmarks.stress_metrics import compute_stress_metrics
from shapesplat.benchmarks.stress_report import save_stress_summary
from shapesplat.config import load_config
from shapesplat.data.image_io import load_image
from shapesplat.datasets.manifest import load_manifest
from shapesplat.experiments.comparison_runner import run_comparison_for_image
from shapesplat.experiments.single_image import run_single_image_experiment
from shapesplat.frontend.file_mask_loader import load_mask_file
from shapesplat.utils.seed import seed_everything


def _render_from_output(output_dir: Path, masks: torch.Tensor):
    ownership_path = output_dir / "ownership.npy"
    ownership = torch.from_numpy(np.load(ownership_path)).float() if ownership_path.exists() else masks.float()
    depth = torch.ones(masks.shape[-2:], dtype=torch.float32)
    return SimpleNamespace(ownership=ownership, depth=depth)


def run_stress_benchmark(
    config_path: str | Path,
    manifest_path: str | Path,
    out_dir: str | Path,
    max_images: int | None = None,
    run_comparison: bool = False,
    run_dummy_baselines: bool = True,
    save_visuals: bool = True,
) -> list[dict]:
    """运行 stress benchmark；单张失败会记录 error 并继续。"""

    cfg = load_config(config_path)
    cfg.setdefault("frontend", {})["mask_source"] = "file"
    seed_everything(int(cfg.get("seed", 0)))
    records = load_manifest(manifest_path)
    if max_images is not None:
        records = records[: max(0, int(max_images))]
    out = Path(out_dir)
    per_image = out / "per_image"
    rows: list[dict] = []
    for idx, record in enumerate(records, start=1):
        image_dir = per_image / record.image_id
        try:
            print(f"[{idx}/{len(records)}] stress: {record.image_id}")
            image = load_image(record.image_path, size=int(cfg["image"]["size"]))
            masks = load_mask_file(record.metadata["mask_path"], image_hw=image.shape[-2:], cfg=cfg).masks
            meta = load_stress_metadata(record.metadata["metadata_path"])
            if run_comparison:
                comp_rows = run_comparison_for_image(
                    image,
                    masks,
                    cfg,
                    image_dir,
                    record.image_id,
                    run_ours=True,
                    run_dummy_baselines=run_dummy_baselines,
                    save_visuals=save_visuals,
                    save_checkpoint=False,
                )
                for row in comp_rows:
                    if row.get("status") != "success":
                        rows.append({**row, "Subset": meta.subset})
                        continue
                    method_dir = Path(row["output_dir"])
                    try:
                        pred = load_baseline_output(method_dir, row["method"], record.image_id)
                        render = SimpleNamespace(ownership=pred["ownership"], depth=torch.ones_like(masks[0]))
                    except Exception:
                        render = _render_from_output(method_dir, masks)
                    rows.append({**row, **compute_stress_metrics(render, masks, meta), "subset": meta.subset})
            else:
                ours_dir = image_dir / "ours"
                cfg_img = dict(cfg)
                cfg_img["frontend"] = dict(cfg.get("frontend", {}))
                cfg_img["frontend"]["mask_path"] = record.metadata["mask_path"]
                row = run_single_image_experiment(
                    image,
                    cfg_img,
                    ours_dir,
                    image_id=record.image_id,
                    record=record,
                    save_visuals=save_visuals,
                    save_checkpoint=False,
                    eval_metrics=True,
                )
                rows.append({**row, **compute_stress_metrics(_render_from_output(ours_dir, masks), masks, meta), "method": "ours", "subset": meta.subset})
        except Exception as exc:
            image_dir.mkdir(parents=True, exist_ok=True)
            err = {"image_id": record.image_id, "status": "failed", "error": str(exc), "Subset": record.metadata.get("subset", "unknown")}
            (image_dir / "error.json").write_text(json.dumps(err, indent=2, ensure_ascii=False), encoding="utf-8")
            rows.append(err)
            print(f"Warning: stress sample failed: {record.image_id}: {exc}")
    save_stress_summary(rows, out)
    return rows

